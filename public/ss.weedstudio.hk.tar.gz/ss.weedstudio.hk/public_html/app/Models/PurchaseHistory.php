<?php


namespace App\Models;

use App\Utils\Tools;

class PurchaseHistory extends Model
{
    protected $table = "user_purchase_hostory";
	
	
}