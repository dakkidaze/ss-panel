<?php

namespace App\Models;

/**
 * Node Model
 */

class Node extends Model

{
    protected $table = "ss_node";

}
