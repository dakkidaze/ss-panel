<?php

namespace App\Models;

/**
 * InviteCode Model
 */

class InviteCode extends Model

{
    protected $table = "ss_invite_code";

}
