<?php
/* Smarty version 3.1.29, created on 2016-02-25 20:28:24
  from "/home/admin/web/ss.weedstudio.hk/public_html/resources/views/default/user/invite.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_56cef368ce5cb5_94954260',
  'file_dependency' => 
  array (
    '9740ca37bbf399c23f61a33d7235278f3ddb6555' => 
    array (
      0 => '/home/admin/web/ss.weedstudio.hk/public_html/resources/views/default/user/invite.tpl',
      1 => 1456391846,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:user/main.tpl' => 1,
    'file:user/footer.tpl' => 1,
  ),
),false)) {
function content_56cef368ce5cb5_94954260 ($_smarty_tpl) {
$_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:user/main.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            邀請
            <small>Invite</small>
        </h1>
    </section>

    <!-- Main content --><!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-sm-12">
                <div id="msg-error" class="alert alert-warning alert-dismissable" style="display:none">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <h4><i class="icon fa fa-warning"></i> 出錯了!</h4>

                    <p id="msg-error-p"></p>
                </div>
            </div>
        </div>
        <div class="row">
            <!-- left column -->
            <div class="col-md-6">
                <!-- general form elements -->
                <div class="box box-primary">
                    <div class="box-header">
                        <i class="fa fa-rocket"></i>

                        <h3 class="box-title">邀請</h3>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <p>當前您可以生成<code><?php echo $_smarty_tpl->tpl_vars['user']->value->invite_num;?>
</code>個邀請碼。 </p>
                        <?php if ($_smarty_tpl->tpl_vars['user']->value->invite_num) {?>
                            <button id="invite" class="btn btn-sm btn-info">生成我的邀請碼</button>
                        <?php }?>
                    </div>
                    <!-- /.box -->
                    <div class="box-header">
                        <h3 class="box-title">我的邀請碼</h3>
                    </div>
                    <!-- /.box-header -->
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                            <tr>
                                <th>###</th>
                                <th>邀請碼(點右鍵複製鏈接)</th>
                                <th>狀態</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php
$_from = $_smarty_tpl->tpl_vars['codes']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_code_0_saved_item = isset($_smarty_tpl->tpl_vars['code']) ? $_smarty_tpl->tpl_vars['code'] : false;
$_smarty_tpl->tpl_vars['code'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['code']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['code']->value) {
$_smarty_tpl->tpl_vars['code']->_loop = true;
$__foreach_code_0_saved_local_item = $_smarty_tpl->tpl_vars['code'];
?>
                                <tr>
                                    <td><b><?php echo $_smarty_tpl->tpl_vars['code']->value->id;?>
</b></td>
                                    <td><a href="/auth/register?code=<?php echo $_smarty_tpl->tpl_vars['code']->value->code;?>
" target="_blank"><?php echo $_smarty_tpl->tpl_vars['code']->value->code;?>
</a>
                                    </td>
                                    <td>可用</td>
                                </tr>
                            <?php
$_smarty_tpl->tpl_vars['code'] = $__foreach_code_0_saved_local_item;
}
if ($__foreach_code_0_saved_item) {
$_smarty_tpl->tpl_vars['code'] = $__foreach_code_0_saved_item;
}
?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="callout callout-warning">
                    <h4>注意！</h4>

                    <p>邀請碼請給認識的需要的人。</p>

                    <p>邀請有記錄，若被邀請的人違反用戶協議，您將會有連帶責任。</p>
                </div>

                <div class="callout callout-info">
                    <h4>說明</h4>

                    <p>用戶註冊48小時後，才可以生成邀請碼。</p>

                    <p>邀請碼暫時無法購買，請珍惜。</p>

                    <p>公共頁面不定期發放邀請碼，如果用完邀請碼可以關注公共邀請。</p>
                </div>
            </div>
            <!-- /.col (right) -->
        </div>
    </section>
    <!-- /.content -->
</div><!-- /.content-wrapper -->

<?php echo '<script'; ?>
>
    $(document).ready(function () {
        $("#invite").click(function () {
            $.ajax({
                type: "POST",
                url: "/user/invite",
                dataType: "json",
                success: function (data) {
                    window.location.reload();
                },
                error: function (jqXHR) {
                    alert("發生錯誤：" + jqXHR.status);
                }
            })
        })
    })
<?php echo '</script'; ?>
>

<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:user/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
