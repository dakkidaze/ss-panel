<?php
/* Smarty version 3.1.29, created on 2016-02-25 19:45:43
  from "/home/admin/web/ss.weedstudio.hk/public_html/resources/views/default/user/buytraffic.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_56cee967d50431_98260065',
  'file_dependency' => 
  array (
    'cd0d8dd0338e5ab4fcc473ba0fdcf1f198447370' => 
    array (
      0 => '/home/admin/web/ss.weedstudio.hk/public_html/resources/views/default/user/buytraffic.tpl',
      1 => 1456400741,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:user/main.tpl' => 1,
    'file:user/footer.tpl' => 1,
  ),
),false)) {
function content_56cee967d50431_98260065 ($_smarty_tpl) {
$_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:user/main.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            購買流量
            <small>Traffic Store</small>
        </h1>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="col-xs-12">
                <div id="msg-error" class="alert alert-warning alert-dismissable" style="display:none">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <h4><i class="icon fa fa-warning"></i> 出錯了!</h4>

                    <p id="msg-error-p"></p>
                </div>
                <div id="msg-success" class="alert alert-success alert-dismissable" style="display:none">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <h4><i class="icon fa fa-info"></i> 購買成功!</h4>

                    <p id="msg-success-p"></p>
                </div>
            </div>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                	<?php if ((isset($_smarty_tpl->tpl_vars['packages']->value))) {?>
                    <div class="box-body table-responsive no-padding">
                        <?php echo $_smarty_tpl->tpl_vars['packages']->value->render();?>

                        <table class="table table-hover">
                            <tr>
                                <th>ID</th>
                                <th>流量套餐</th>
                                <th>可用流量</th>
                                <th>價格</th>
                                <th>套餐類型</th>
                                <th>購買</th>
                            </tr>
                            <?php
$_from = $_smarty_tpl->tpl_vars['packages']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_package_0_saved_item = isset($_smarty_tpl->tpl_vars['package']) ? $_smarty_tpl->tpl_vars['package'] : false;
$_smarty_tpl->tpl_vars['package'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['package']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['package']->value) {
$_smarty_tpl->tpl_vars['package']->_loop = true;
$__foreach_package_0_saved_local_item = $_smarty_tpl->tpl_vars['package'];
?>
                                <tr>
                                    <td>#<?php echo $_smarty_tpl->tpl_vars['package']->value->id;?>
</td>
                                    <td><?php echo $_smarty_tpl->tpl_vars['package']->value->packagename;?>
</td>
                                    <td><?php echo $_smarty_tpl->tpl_vars['package']->value->package_traffic_m();?>
</td>
                                    <td><?php echo $_smarty_tpl->tpl_vars['package']->value->price();?>
</td>
                                    <td><?php echo $_smarty_tpl->tpl_vars['package']->value->package_type();?>
</td>
                                    <td><a class="btn btn-info btn-sm" href="/user/buy/<?php echo $_smarty_tpl->tpl_vars['package']->value->id;?>
">購買</a></td>
                                </tr>
                            <?php
$_smarty_tpl->tpl_vars['package'] = $__foreach_package_0_saved_local_item;
}
if ($__foreach_package_0_saved_item) {
$_smarty_tpl->tpl_vars['package'] = $__foreach_package_0_saved_item;
}
?>
                        </table>
                        <?php echo $_smarty_tpl->tpl_vars['packages']->value->render();?>

                    </div><!-- /.box-body -->
                    <?php }?>
                    <?php if ((isset($_smarty_tpl->tpl_vars['data']->value))) {?>
                    <div class="box-body table-responsive no-padding">
                       <div class="box box-primary">
                    <div class="box-header">
                        <i class="fa fa-shopping-cart"></i>

                        <h3 class="box-title">購買詳情</h3>
                    </div>
                    <div class="box-body">
                        <dl class="dl-horizontal">
                        	
                            <dt>現時流量</dt>
                            <dd><?php echo $_smarty_tpl->tpl_vars['user']->value->unusedTraffic();?>
</dd>
                            <dt>購買增加流量</dt>
                            <dd><?php echo $_smarty_tpl->tpl_vars['data']->value['package']->packagename;?>
(<?php echo $_smarty_tpl->tpl_vars['data']->value['package']->package_traffic_m();?>
)</dd>
                            <dt>購買後流量</dt>
                            <dd><?php echo $_smarty_tpl->tpl_vars['user']->value->guessUnusedTraffic($_smarty_tpl->tpl_vars['data']->value['package']->package_traffic_m);?>
</dd>
                            <dt>現時結餘</dt>
                            <dd><?php echo $_smarty_tpl->tpl_vars['data']->value['credit'];?>
</dd>
                            <dt>流量總值</dt>
                            <dd>-<?php echo $_smarty_tpl->tpl_vars['data']->value['package']->price;?>
</dd>
                            <dt>購買後結餘</dt>
                            <dd><?php echo $_smarty_tpl->tpl_vars['data']->value['credit']-$_smarty_tpl->tpl_vars['data']->value['package']->price;?>
</dd>
                            
                        </dl>

                    </div>
                    	<div class="box-footer">
                    		<?php if (($_smarty_tpl->tpl_vars['data']->value['credit']-$_smarty_tpl->tpl_vars['data']->value['package']->price >= 0)) {?>
                        	<button type="submit" id="confirm-buy" class="btn btn-primary">購買</button>
                        	<?php } else { ?>
                        	<button type="" id="" class="btn btn-danger" disabled>結餘不足</button>
                        	<?php }?>
                    	</div>
                    </div><!-- /.box-body -->
                    <?php }?>
                </div><!-- /.box -->
            </div>
        </div>

    </section><!-- /.content -->
</div><!-- /.content-wrapper -->

<?php echo '<script'; ?>
>
    $("#msg-success").hide();
    $("#msg-error").hide();
    $("#ss-msg-success").hide();
<?php echo '</script'; ?>
>
<?php if ((isset($_smarty_tpl->tpl_vars['data']->value))) {
echo '<script'; ?>
>
    $(document).ready(function () {
        $("#confirm-buy").click(function () {
        	$("#confirm-buy").hide();
            $.ajax({
                type: "POST",
                url: "buypackage",
                dataType: "json",
                data: {
                    traffpackage: <?php echo ($_smarty_tpl->tpl_vars['data']->value['id']);?>

                },
                success: function (data) {
                    if (data.ret) {
                    	console.log(data.ret);
                        $("#msg-success").show();
                        $("#msg-success-p").html(data.msg);
                       	$(".box-body").html("");
                    } else {
                    	console.log(data.ret);
                        $("#msg-error").show();
                        $("#msg-error-p").html(data.msg);
                    }
                },
                error: function (jqXHR) {
                    alert("發生錯誤：" + jqXHR.status);
                }
            })
        })
    })
<?php echo '</script'; ?>
>
<?php }
$_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:user/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
