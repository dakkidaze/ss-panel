<?php
/* Smarty version 3.1.29, created on 2016-02-25 18:20:04
  from "/home/admin/web/ss.weedstudio.hk/public_html/resources/views/default/user/node.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_56ced554bc0c17_58746873',
  'file_dependency' => 
  array (
    '9e5b8af096b82c725d6e123cff6489ee3239531a' => 
    array (
      0 => '/home/admin/web/ss.weedstudio.hk/public_html/resources/views/default/user/node.tpl',
      1 => 1456391857,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:user/main.tpl' => 1,
    'file:user/footer.tpl' => 1,
  ),
),false)) {
function content_56ced554bc0c17_58746873 ($_smarty_tpl) {
$_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:user/main.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>


<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            節點列表
            <small>Node List</small>
        </h1>
    </section>

    <!-- Main content -->
    <section class="content">
        <!-- START PROGRESS BARS -->
        <div class="row">
            <div class="col-md-12">
                <div class="callout callout-warning">
                    <h4>注意!</h4>
                    <p>請勿在任何地方公開節點地址！</p>
                    <p>流量比例為0.5及使用1000MB按照500MB流量記錄記錄結算.</p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="box box-info">
                    <div class="box-header">
                        <i class="fa fa-th-list"></i>

                        <h3 class="box-title">節點</h3>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <?php
$_from = $_smarty_tpl->tpl_vars['nodes']->value;
if (!is_array($_from) && !is_object($_from)) {
settype($_from, 'array');
}
$__foreach_node_0_saved_item = isset($_smarty_tpl->tpl_vars['node']) ? $_smarty_tpl->tpl_vars['node'] : false;
$_smarty_tpl->tpl_vars['node'] = new Smarty_Variable();
$_smarty_tpl->tpl_vars['node']->_loop = false;
foreach ($_from as $_smarty_tpl->tpl_vars['node']->value) {
$_smarty_tpl->tpl_vars['node']->_loop = true;
$__foreach_node_0_saved_local_item = $_smarty_tpl->tpl_vars['node'];
?>
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="info-box">
                                        <span class="info-box-icon bg-aqua"><i class="fa fa-server"></i></span>

                                        <div class="info-box-content">
                                            <div class=row>
                                                <div class="col-sm-6">
                                                    <div class="info-box-number">
                                                        <a href="./node/<?php echo $_smarty_tpl->tpl_vars['node']->value->id;?>
"><?php echo $_smarty_tpl->tpl_vars['node']->value->name;?>
</a> <sub><span
                                                                    class="label label-success"><?php echo $_smarty_tpl->tpl_vars['node']->value->status;?>
</span></sub>
                                                    </div>

                                                    <div class="info-box-text row">
                                                        <div class="col-xs-4 col-sm-2">地址：</div>
                                                        <div class="col-xs-8 col-sm-4"><span
                                                                    class="label label-danger"><?php echo $_smarty_tpl->tpl_vars['node']->value->server;?>
</span>
                                                        </div>
                                                        <div class="col-xs-4 col-sm-2">端口：</div>
                                                        <div class="col-xs-8 col-sm-4"><span
                                                                    class="label label-danger"><?php echo $_smarty_tpl->tpl_vars['user']->value->port;?>
</span>
                                                        </div>
                                                        <div class="col-xs-4 col-sm-2">密碼：</div>
                                                        <div class="col-xs-8 col-sm-4"><span
                                                                    class="label label-danger"><?php echo $_smarty_tpl->tpl_vars['user']->value->passwd;?>
</span>
                                                        </div>
                                                        <div class="col-xs-4 col-sm-2">加密：</div>
                                                        <div class="col-xs-8 col-sm-4">
                                                        <span class="label label-danger">
                                                            <?php if ($_smarty_tpl->tpl_vars['node']->value->custom_method == 1) {?>
                                                                <?php echo $_smarty_tpl->tpl_vars['user']->value->method;?>

                                                            <?php } else { ?>
                                                                <?php echo $_smarty_tpl->tpl_vars['node']->value->method;?>

                                                            <?php }?>
                                                        </span>

                                                        </div>
                                                        <div class="col-xs-4 col-sm-2">流量比例：</div>
                                                        <div class="col-xs-8 col-sm-4"><span
                                                                    class="label label-danger"><?php echo $_smarty_tpl->tpl_vars['node']->value->traffic_rate;?>
</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-5">
                                                    <div class="progress-description"><?php echo $_smarty_tpl->tpl_vars['node']->value->info;?>
</div>
                                                </div>
                                            </div>


                                        </div>
                                        <!-- /.info-box-content -->
                                    </div>
                                    <!-- /.info-box -->
                                </div>
                            </div>
                        <?php
$_smarty_tpl->tpl_vars['node'] = $__foreach_node_0_saved_local_item;
}
if ($__foreach_node_0_saved_item) {
$_smarty_tpl->tpl_vars['node'] = $__foreach_node_0_saved_item;
}
?>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
            <!-- /.col (left) -->
        </div>
        <!-- /.row --><!-- END PROGRESS BARS -->
    </section>
    <!-- /.content -->
</div><!-- /.content-wrapper -->


<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:user/footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
