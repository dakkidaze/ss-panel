<?php
/* Smarty version 3.1.29, created on 2016-02-25 17:17:13
  from "/home/admin/web/ss.weedstudio.hk/public_html/resources/views/default/user/footer.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_56cec699ed39d7_61541436',
  'file_dependency' => 
  array (
    '4220e0106676d3e23fbca8ce01c180cdac13d47a' => 
    array (
      0 => '/home/admin/web/ss.weedstudio.hk/public_html/resources/views/default/user/footer.tpl',
      1 => 1456391823,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_56cec699ed39d7_61541436 ($_smarty_tpl) {
?>
<footer class="main-footer">
    <div class="pull-right hidden-xs">
        Made with Love
    </div>
    <strong>Copyright &copy; 2016 <a href="#"><?php echo $_smarty_tpl->tpl_vars['config']->value['appName'];?>
</a> </strong>
    All rights reserved. Powered by <b>ss-panel</b> <?php echo $_smarty_tpl->tpl_vars['config']->value['version'];?>
 | <a href="/tos">服務條款 </a>
</footer>
</div><!-- ./wrapper -->


<!-- Bootstrap 3.3.2 JS -->
<?php echo '<script'; ?>
 src="/assets/public/js/bootstrap.min.js" type="text/javascript"><?php echo '</script'; ?>
>
<!-- SlimScroll -->
<?php echo '<script'; ?>
 src="/assets/public/plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"><?php echo '</script'; ?>
>
<!-- FastClick -->
<?php echo '<script'; ?>
 src='/assets/public/plugins/fastclick/fastclick.min.js'><?php echo '</script'; ?>
>
<!-- AdminLTE App -->
<?php echo '<script'; ?>
 src="/assets/public/js/app.min.js" type="text/javascript"><?php echo '</script'; ?>
>
</body>
</html>
<?php }
}
